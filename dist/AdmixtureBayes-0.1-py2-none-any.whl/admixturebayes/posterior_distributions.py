from argparse import ArgumentParser
from downstream_analysis_tool import (thinning, iterate_over_output_file, always_true, make_Rtree, make_full_tree, read_true_values,
                                      make_Rcovariance, cov_truecov, topology_identity,get_pops,compare_pops,extract_number_of_sadmixes, 
                                      read_one_line,summarize_all_results, create_treemix_csv_output, topology, float_mean, mode,
                                      create_treemix_sfull_tree_csv_output, subgraph, subsets, thinning_on_admixture_events)
                                      
import warnings 


def read_lines(input_file):
    lines=[]
    if not input_file:
        return [[],['no_admixes','nodes']]
    with open(input_file,  'r') as f:
        f.readline()  ##header line
        for r in f.readlines():
            a=r.split(';')
            nodes=a[0].strip().split()
            summaries=map(strip,a[1].split(','))
            lines.append([nodes,  summaries])
    return lines


summary_dependencies={'topology': (['Rtree'], []),
                      'cov_dist': (['Rtree'], ['covariance']),
                      'tree': ([], []),
                      'nodes': (['Rtree'], []),
                      'no_admixes': ([], []),
                      'no_sadmixes': (['Rtree'], []),
                      }


def main(args):
    parser = ArgumentParser(usage='pipeline for post analysis', version='0.1')
    parser.add_argument('--mcmc_output_file', type=str, required=True,  help='The output file of a run with AdmixtureBayes.' )
    parser.add_argument('--summary_file',  type=str,  default='',  help='A file to specify which summaries to calculate')

    parser.add_argument('--no_samples',  type=int,  default=1000,  help='the number of trees to include from the dataset')
    parser.add_argument('--burn_in_fraction', default=0.5, type=float, help='the proportion of the rows that are discarded as burn in period')
    parser.add_argument('--output_file',  default='summaries.csv',  help='The file in which to put the results. Each column is a summary (a line from the summary_file if the summary_file is used) and there are no_samples rows(unless constraints have been applied).')
    parser.add_argument('--covariance_matrix_file', required=True, type=str, help='The file where the covariance matrix is. Even if none of the requested summaries depend on the covariance matrix, this file is the only one that gives the population names and if not supplied, it will cause a warning.')
    parser.add_argument('--no_sort', default=False, action='store_true', help='often the tree is sorted according to the leaf names. no_sort willl assume that they are not sorted according to this but in the order specified by the covariance matrix file. This flag should almost never be applied.')

    options=parser.parse_args(args)
    columns={}

    if options.covariance_matrix_file:
        nodes=read_one_line()
        if not options.no_sort:
            nodes = sorted(nodes)

    for subset,  summaries in read_lines(options.summary_file):
        for summary in summaries:
            column_name='-'.join(subset)+'_'+summary
            if column_name in columns:
                warnings.warn('calculating the exact same summary twice')
        rowsum_function=[make_Rtree, make_Rcovariance,
                         cov_dist, topology]create_rowsummary(summaries, summary_dependencies, subset, nodes)



                
    


    
if __name__=='__main__':
    import sys
    main(sys.argv[1:])
